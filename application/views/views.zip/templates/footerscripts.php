<!-- Core -->
<script src="<?=base_url("assets")?>/vendor/jquery/jquery.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/popper/popper.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="<?=base_url("assets")?>/js/vendor/jquery.easing.js"></script>
<script src="<?=base_url("assets")?>/js/ie10-viewport-bug-workaround.js"></script>
<script src="<?=base_url("assets")?>/js/slidebar/slidebar.js"></script>
<script src="<?=base_url("assets")?>/js/classie.js"></script>

<!-- Smooth Scroll 
<script src="<?=base_url("assets/js/smooth-scroll.js")?>"></script>
-->

<!-- Bootstrap Extensions -->
<script src="<?=base_url("assets")?>/vendor/bootstrap-dropdown-hover/js/bootstrap-dropdown-hover.js"></script>
<script src="<?=base_url("assets")?>/vendor/bootstrap-notify/bootstrap-growl.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/scrollpos-styler/scrollpos-styler.js"></script>

<!-- Plugins: Sorted A-Z -->
<script src="<?=base_url("assets")?>/vendor/adaptive-backgrounds/adaptive-backgrounds.js"></script>
<script src="<?=base_url("assets")?>/vendor/countdown/js/jquery.countdown.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/dropzone/dropzone.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/easy-pie-chart/jquery.easypiechart.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/fancybox/js/jquery.fancybox.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/flatpickr/flatpickr.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/flip/flip.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/footer-reveal/footer-reveal.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/gradientify/jquery.gradientify.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/headroom/headroom.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/headroom/jquery.headroom.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/input-mask/input-mask.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/instafeed/instafeed.js"></script>
<script src="<?=base_url("assets")?>/vendor/milestone-counter/jquery.countTo.js"></script>
<script src="<?=base_url("assets")?>/vendor/nouislider/js/nouislider.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/paraxify/paraxify.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/select2/js/select2.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/sticky-kit/sticky-kit.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/swiper/js/swiper.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/textarea-autosize/autosize.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/typeahead/typeahead.bundle.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/typed/typed.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/viewport-checker/viewportchecker.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/wow/wow.min.js"></script>

<!-- Isotope -->
<script src="<?=base_url("assets")?>/vendor/isotope/isotope.min.js"></script>
<script src="<?=base_url("assets")?>/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>



<!-- App JS -->
<script src="<?=base_url("assets")?>/js/boomerang.min.js"></script>

<script type="text/javascript">
	/*
	$('.how-it-works').click(function(){
		$('html, body').animate({
			scrollTop: $( $(this).attr('href') ).offset().top
		}, 500);
		return false;
	});
	*/
</script>

</body>
</html>
